const fs = require('fs');
const path = require('path');

const dirPath = path.join(__dirname,'crud');
const filePath = `${dirPath}/data.txt`;

fs.writeFileSync(filePath,"Sample Data of File"); 

fs.readFile(filePath,'utf8',(err,element)=>{
    console.log(element);
})

fs.appendFile(filePath,'This is some sample data',(err)=>
{
    if(!err)
    console.log(" File is Updated");
}
)

fs.rename(filePath,'${dirPath}/data1.txt',(err)=>
{
    if(!err)
    console.log(" file name changed!!")
})

fs.unlinkSync(`${dirPath}/data.txt`);