"use strict";

const prompt = require("prompt-sync")({sigint:true});

let number =paeseInt(prompt("Enter an Integer Number : "));


switch((number % 2)){
    case 0:
        console.log(`${number} is even Number`);
        break;

    case 1:
        console.log(`${number} is odd Number`);
        break;
}
